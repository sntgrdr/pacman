# frozen_string_literal: true

require 'rails_helper'

RSpec.describe BoardsController, type: :controller do
  describe '#load_game' do
    context 'when the file exists' do
      let(:file_name) { 'input.txt' }

      before do
        get :load_game, params: { txt_file: file_name }
      end

      it 'assigns the @coins instance variable' do
        expect(assigns(:coins)).to eq(7)
      end

      it 'assigns the @final_x instance variable' do
        expect(assigns(:final_x)).to eq(1)
      end

      it 'assigns the @final_y instance variable' do
        expect(assigns(:final_y)).to eq(4)
      end

      it 'renders the load_game template' do
        expect(response).to render_template(:load_game)
      end
    end

    context 'when the file does not exist' do
      let(:file_name) { 'invalid_file.txt' }

      before do
        allow(controller).to receive(:file_name).and_return(file_name)
        allow(File).to receive(:exist?).and_return(false)
        get :load_game
      end

      it 'assigns the @error instance variable' do
        expect(assigns(:error)).to eq('File not found')
      end

      it 'returns a 404 status code' do
        expect(response.status).to eq(404)
      end
    end
  end
end
