# frozen_string_literal: true

require 'rails_helper'

RSpec.describe Board, type: :model do
  let(:fixture_file) { fixture_file_upload('input.txt', 'text/plain') }

  let(:file) { File.read(fixture_file) }
  let(:rows) { file.lines.first.strip.split.map(&:to_i).first }
  let(:cols) { file.lines.first.strip.split.map(&:to_i).last }
  let(:initial_x) { file.lines[1].strip.split.map(&:to_i).first }
  let(:initial_y) { file.lines[1].strip.split.map(&:to_i).last }
  let(:movements) { file.lines[2].strip }
  let(:walls) { file.lines[3..].map { |line| line.strip.split.map(&:to_i) } }

  describe '#initialize' do
    it 'initializes the board attributes' do
      board = Board.new(rows, cols, initial_x, initial_y, movements, walls)

      expect(board.rows).to eq(rows)
      expect(board.cols).to eq(cols)
      expect(board.initial_x).to eq(initial_x)
      expect(board.initial_y).to eq(initial_y)
      expect(board.coins).to eq(0)
    end
  end

  describe '#play' do
    context 'when is input.txt' do
      it 'returns self' do
        board = Board.new(rows, cols, initial_x, initial_y, movements, walls)
        result = board.play

        expect(result).to eq(board)
      end

      it 'updates the board attributes according to movements' do
        board = Board.new(rows, cols, initial_x, initial_y, movements, walls)
        board.play

        expect(board.initial_x).to eq(1)
        expect(board.initial_y).to eq(4)
        expect(board.coins).to eq(7)
      end
    end

    context 'when is edge.txt' do
      let(:fixture_file) { fixture_file_upload('edge.txt', 'text/plain') }

      it 'returns self' do
        board = Board.new(rows, cols, initial_x, initial_y, movements, walls)
        result = board.play

        expect(result).to eq(board)
      end

      it 'updates the board attributes according to movements' do
        board = Board.new(rows, cols, initial_x, initial_y, movements, walls)
        board.play

        expect(board.initial_x).to eq(-1)
        expect(board.initial_y).to eq(-1)
        expect(board.coins).to eq(0)
      end
    end
  end
end
