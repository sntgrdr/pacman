# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version
  '3.1.1'

* Rails version
  '7.0.4'

* System dependencies
  You must have Ruby and Rails instaleld

* Usage
  In your command line:
    - go to the directory of the App 'cd /pacmanish-app/'
    - then 'rails s'

    You will be redirected to the home page. That is an input to enter the file_name you want to use.
    Valid ones are: 'input', 'edge', 'generic' and 'runtime'.
    You can add or not the extention. If you do it must be '.txt'
  

* Database creation
  No database is used

* How to run the test suite
  In your command line:
    - go to the directory of the App 'cd /pacmanish-app/'
    - then 'cd spec'
    - finally run 'rspec'
