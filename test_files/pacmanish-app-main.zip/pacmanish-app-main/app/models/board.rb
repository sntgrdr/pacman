# frozen_string_literal: true

class Board
  attr_reader :rows, :cols, :initial_x, :initial_y, :coins

  def initialize(rows, cols, initial_x, initial_y, movements, walls)
    @rows = rows
    @cols = cols
    @initial_x = initial_x.positive? && initial_x <= @cols ? initial_x : -1
    @initial_y = initial_y.positive? && initial_y <= @rows ? initial_y : -1
    @movements = movements
    @walls = walls
    @path_done = []
    @coins = 0
  end

  def play
    @movements.each_char do |movement|
      case movement
      when 'N'
        move_pacman(0, 1)
      when 'E'
        move_pacman(1, 0)
      when 'S'
        move_pacman(0, -1)
      when 'W'
        move_pacman(-1, 0)
      end
    end
    self
  end

  private

  def valid_move?(x, y)
    return false if x.negative? || x >= @cols || y.negative? || y >= @rows

    return false if @walls.include?([x, y])

    true
  end

  def move_pacman(dx, dy)
    new_x = @initial_x + dx
    new_y = @initial_y + dy

    return false unless valid_move?(new_x, new_y)

    @initial_x = new_x
    @initial_y = new_y
    @coins += 1 unless @path_done.include?([new_x, new_y])
    @path_done << [new_x, new_y]
    true
  end
end
