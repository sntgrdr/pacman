# frozen_string_literal: true

class BoardsController < ApplicationController
  def start; end

  def load_game
    return file_not_found unless File.exist?("files/#{file_name}")

    @coins = board&.coins
    @final_x = board&.initial_x
    @final_y = board&.initial_y
  end

  private

  def board
    @data = File.read("files/#{file_name}")
    @board = Board.new(rows, cols, initial_x, initial_y, movements, walls).play if @data
  end

  def file_name
    params[:txt_file]&.include?('.txt') ? params[:txt_file] : "#{params[:txt_file]}.txt"
  end

  def rows
    @data.lines.first.strip.split.map(&:to_i).first
  end

  def cols
    @data.lines.first.strip.split.map(&:to_i).last
  end

  def initial_x
    @data.lines[1].strip.split.map(&:to_i).first
  end

  def initial_y
    @data.lines[1].strip.split.map(&:to_i).last
  end

  def walls
    @data.lines[3..].map { |line| line.strip.split.map(&:to_i) }
  end

  def movements
    @data.lines[2].strip
  end

  def file_not_found
    @error = 'File not found'
    render status: :not_found
  end
end
