# frozen_string_literal: true

Rails.application.routes.draw do
  resources :boards do
    collection do
      get :load_game
    end
  end

  root 'boards#start'
end
